// RESPOSTA DO PROFESSOR · Minha Lista de Filmes

// PASSO 1 · elementos (Dia 04)
const form = document.getElementById('form-filme');
const inputTitulo = document.getElementById('titulo');
const selectTipo = document.getElementById('tipo');
const lista = document.getElementById('lista');
const contador = document.getElementById('contador');
const btnLimpar = document.getElementById('btn-limpar');

// PASSO 2 · memória (Dia 05)
const filmes = [];

// PASSO 3 · função que desenha a lista (Dia 05)
function mostrarFilmes() {
  lista.innerHTML = '';
  filmes.forEach(function (filme, posicao) {
    const card = document.createElement('article');
    card.classList.add('card', 'tipo-' + filme.tipo);
    const info = document.createElement('div');
    info.classList.add('info');
    const titulo = document.createElement('h3');
    titulo.textContent = filme.titulo;
    const detalhe = document.createElement('small');
    detalhe.textContent = 'Tipo: ' + filme.tipo;
    info.appendChild(titulo);
    info.appendChild(detalhe);
    const btnRemover = document.createElement('button');
    btnRemover.type = 'button';
    btnRemover.textContent = 'Remover';
    btnRemover.classList.add('btn-remover');
    btnRemover.addEventListener('click', function () {
      filmes.splice(posicao, 1);
      mostrarFilmes();
    });
    card.appendChild(info);
    card.appendChild(btnRemover);
    lista.appendChild(card);
  });
  contador.textContent = filmes.length;
}

// PASSO 4 · envio do formulário (Dia 04 + Dia 05)
form.addEventListener('submit', function (event) {
  event.preventDefault();
  const titulo = inputTitulo.value.trim();
  const tipo = selectTipo.value;
  if (titulo === '') {
    alert('Escreva o título!');
    return;
  }
  filmes.push({ titulo: titulo, tipo: tipo });
  mostrarFilmes();
  form.reset();
  inputTitulo.focus();
});

// PASSO 5 · limpar lista
btnLimpar.addEventListener('click', function () {
  filmes.length = 0;
  mostrarFilmes();
});

// PASSO 6 · primeira tela
mostrarFilmes();
